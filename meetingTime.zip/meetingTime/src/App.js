import React, { Component } from "react";
import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const getBg = () => {
      const changeColor = "0123456789ABCDEF".split("");
      let addPrifixColor = "#";
      for (let i = 0; i < 6; i++) {
        addPrifixColor += changeColor[Math.floor(Math.random() * 16)];
      }
      return addPrifixColor;
    };

    const meetingTime = [
      "9am",
      "10am",
      "11am",
      "12pm",
      "1pm",
      "2pm",
      "3pm",
      "4pm",
      "5pm",
      "6pm",
      "7pm",
      "8pm",
      "9pm"
    ];

    const listItems = meetingTime.map(meetingTime => (
      <li key={meetingTime} className="meeting-time">
        <span>{meetingTime}</span>
      </li>
    ));

    // calender function

    var eventsForMeeting = [
      {
        id: 123,
        start: 60,
        end: 120
      },
      {
        id: 124,
        start: 300,
        end: 600
      },
      {
        id: 125,
        start: 480,
        end: 600
      },
      {
        id: 126,
        start: 440,
        end: 550
      },
      {
        id: 127,
        start: 200,
        end: 300
      },
      {
        id: 128,
        start: 600,
        end: 620
      },
      {
        id: 129,
        start: 600,
        end: 720
      }
    ];

    const calculteWidth = () => {
      const collisionArray = checkCollision(eventsForMeeting);
      const widthArray = [];
      collisionArray.map(m => {
        const c = m.cols.length;
        const rank = m.colsBefore.length;
        const width = 600 / c;
        const left = width * rank;
        const a = {
          id: m.id,
          width: width,
          left: left,
          rank: rank,
          top: m.start * 2,
          height: (m.end - m.start) * 2,
          time: ((m.end - m.start) * 2) / 120
        };
        widthArray.push(a);
        console.log(a);
      });
      return widthArray;
    };

    const collidesWith = (a, b) => {
      return a.end > b.start && a.start < b.end;
    };

    const checkCollision = eventArr => {
      for (let i = 0; i < eventArr.length; i++) {
        eventArr[i].cols = [];
        eventArr[i].colsBefore = [];
        for (let j = 0; j < eventArr.length; j++) {
          if (collidesWith(eventArr[i], eventArr[j])) {
            eventArr[i].cols.push(j);
            if (eventArr[i].start > eventArr[j].start)
              eventArr[i].colsBefore.push(j);
          }
        }
      }
      return eventArr;
    };

    const widthArray = calculteWidth();
    console.log("ashish", widthArray.height);

    const calendarShowBlock = widthArray.map(eventsForMeeting => (
      <div
        key={eventsForMeeting.id}
        className="event"
        id={eventsForMeeting.id}
        style={{
          top: eventsForMeeting.top + "px",
          height: eventsForMeeting.height + "px",
          width: `${eventsForMeeting.width}px`,
          left: `${eventsForMeeting.left}px`,
          background: getBg()
        }}
      >
        <div className="container-meeting-time">
          <div className="column-meeting-period">
            Metting In Hours
            {eventsForMeeting.time.toFixed(2)}
          </div>
          <div className="column-meeting-time">
            Metting Id
            {eventsForMeeting.id}
          </div>
        </div>
      </div>
    ));
    return (
      <div className="App">
        <div className="application-wrappe">
          <div className="container">
            <div className="meeting-block">
              <h1 className="app-header">Meeting Scheduler</h1>
              <div id="show-timeline-left">
                <ul className="time-block">{listItems}</ul>
              </div>
              <div id="meetingCalendar" className="meeting-calendar">
                {calendarShowBlock}
              </div>
              <div id="show-timeline-right">
                <ul className="time-block">{listItems}</ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
